//
// Source code producted by Clement Bluzat & Lucas Dalla Costa
// mots_fleches
//

package fr.limayrac.b3rpi;

import fr.limayrac.b3rpi.model.Grille;

public class Start {

    //initialisation d'une grille de 6x6
    public static void main(String[] args) {

        Grille grille;
        new Grille(6, 6);
    }
}
