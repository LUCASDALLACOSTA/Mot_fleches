package fr.limayrac.b3rpi.model;

//Debut de la création de l'intreface de la grille
public interface GrilleInterface {
    public int getHauteur();
    public int getLargeur();
}
