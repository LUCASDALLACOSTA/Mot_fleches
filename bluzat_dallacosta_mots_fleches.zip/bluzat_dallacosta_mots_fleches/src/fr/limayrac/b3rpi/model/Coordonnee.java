package fr.limayrac.b3rpi.model;

public class Coordonnee {

    public int x;
    public int y;

    //ces variables seront utilisées pour donner les coordonnees à chaque case de la grille
    public Coordonnee(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
